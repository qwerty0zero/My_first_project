$("body").on("click", '[href*="#"]', function (e) {
  var fixed_offset = 100;
  $("html,body")
    .stop()
    .animate({ scrollTop: $(this.hash).offset().top }, 1000);
  e.preventDefault();
});

var slideIndex = 1;
showDivs(slideIndex);

function plusDivs(n) {
  showDivs((slideIndex += n));
}

function currentDiv(n) {
  showDivs((slideIndex = n));
}

function showDivs(n) {
  var i;
  var x = document.getElementsByClassName("mySlides");
  var dots = document.getElementsByClassName("demo");
  if (n > x.length) {
    slideIndex = 1;
  }
  if (n < 1) {
    slideIndex = x.length;
  }
  for (i = 0; i < x.length; i++) {
    x[i].style.display = "none";
  }
  for (i = 0; i < dots.length; i++) {
    dots[i].className = dots[i].className.replace(" w3-red", "");
  }
  x[slideIndex - 1].style.display = "block";
}

var slideIndex_2 = 1;
showDivs_2(slideIndex_2);

function plusDivs_2(n_2) {
  showDivs_2((slideIndex_2 += n_2));
}

function currentDiv_2(n_2) {
  showDivs_2((slideIndex_2 = n_2));
}

function showDivs_2(n_2) {
  var i_2;
  var x_2 = document.getElementsByClassName("mySlides-2");
  var dots_2 = document.getElementsByClassName("demo");
  if (n_2 > x_2.length) {
    slideIndex_2 = 1;
  }
  if (n_2 < 1) {
    slideIndex_2 = x_2.length;
  }
  for (i_2 = 0; i_2 < x_2.length; i_2++) {
    x_2[i_2].style.display = "none";
  }
  for (i_2 = 0; i_2 < dots_2.length; i_2++) {
    dots_2[i_2].className_2 = dots_2[i_2].className_2.replace(" w3-red", "");
  }
  x_2[slideIndex_2 - 1].style.display = "block";
}

var slideIndex_3 = 1;
showDivs_3(slideIndex_3);

function plusDivs_3(n_3) {
  showDivs_3((slideIndex_3 += n_3));
}

function currentDiv_3(n_3) {
  showDivs_3((slideIndex_3 = n_3));
}

function showDivs_3(n_3) {
  var i_3;
  var x_3 = document.getElementsByClassName("mySlides-3");
  var dots_3 = document.getElementsByClassName("demo");
  if (n_3 > x_3.length) {
    slideIndex_3 = 1;
  }
  if (n_3 < 1) {
    slideIndex_3 = x_3.length;
  }
  for (i_3 = 0; i_3 < x_3.length; i_3++) {
    x_3[i_3].style.display = "none";
  }
  for (i_3 = 0; i_3 < dots_3.length; i_3++) {
    dots_3[i_3].className_3 = dots_3[i_3].className_3.replace(" w3-red", "");
  }
  x_3[slideIndex_3 - 1].style.display = "block";
}
